import * as readlineSync from 'readline-sync';    
let alturaPersona = readlineSync.question(); 
console.log(alturaPersona);