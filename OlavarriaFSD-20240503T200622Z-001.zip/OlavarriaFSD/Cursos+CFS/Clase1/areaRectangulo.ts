console.log(5*10);
let Base: number= 5;
let Altura: number= 10;
let area: number= Base * Altura;
console.log(area);
console.log("El valor de mi rectangulo es " + area);
/*Esto es una secuencia*/
console.log("1-pescado");
console.log("2-pescado");
/*Comando: ts-node areaRectangulo.ts*/
let numero: number=10;
console.log(numero);
/*Variable delcarada*/
let mensaje: string;
mensaje= "Hola Mundo";
console.log(mensaje);
